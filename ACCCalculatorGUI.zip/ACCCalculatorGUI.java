import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class ACCCalculatorGUI {
    public static void main(String[] args) {
        // Create Frame
        JFrame frame = new JFrame("ACC Calculator");
        frame.setSize(500, 250); // Adjusted size for better UI
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setLayout(new BorderLayout(10, 10)); // Adds spacing

        // Create a panel for form inputs
        JPanel panel = new JPanel();
        panel.setLayout(new GridBagLayout());
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(10, 10, 10, 10); // Padding for components
        gbc.fill = GridBagConstraints.HORIZONTAL;

        // Create Components
        JLabel imsiLabel = new JLabel("Enter IMSI (15 digits):");
        JTextField imsiField = new JTextField(15); // Set width
        JButton calculateButton = new JButton("Calculate ACC");
        JLabel accLabel = new JLabel("ACC:");
        JTextField accField = new JTextField(15);
        accField.setEditable(false); // Make output field non-editable

        // Position Components in Grid
        gbc.gridx = 0;
        gbc.gridy = 0;
        panel.add(imsiLabel, gbc);

        gbc.gridx = 1;
        gbc.gridy = 0;
        panel.add(imsiField, gbc);

        gbc.gridx = 0;
        gbc.gridy = 1;
        panel.add(calculateButton, gbc);

        gbc.gridx = 0;
        gbc.gridy = 2;
        panel.add(accLabel, gbc);

        gbc.gridx = 1;
        gbc.gridy = 2;
        panel.add(accField, gbc);

        // Add Action Listener to Button using the new CalculateActionListener class
        calculateButton.addActionListener(new CalculateActionListener(frame, imsiField, accField));

        // Add Panel to Frame
        frame.add(panel, BorderLayout.CENTER);

        // Center and Show Frame
        frame.setLocationRelativeTo(null); // Center on screen
        frame.setVisible(true);
    }

    // Function to calculate ACC
    public static String calculateACC(String imsi) {
        if (imsi == null || imsi.isEmpty()) {
            return "Invalid IMSI";
        }

        // Get the last digit of IMSI
        char lastChar = imsi.charAt(imsi.length() - 1);
        int lastDigit = Character.getNumericValue(lastChar);

        // Calculate 2^lastDigit
        int accValue = (int) Math.pow(2, lastDigit);

        // Convert to Hexadecimal and format as 4-digit string
        return String.format("%04X", accValue);
    }
}

// Separate ActionListener class for button functionality
class CalculateActionListener implements ActionListener {
    private JTextField imsiField;
    private JTextField accField;
    private JFrame frame;

    public CalculateActionListener(JFrame frame, JTextField imsiField, JTextField accField) {
        this.frame = frame;
        this.imsiField = imsiField;
        this.accField = accField;
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        String imsi = imsiField.getText().trim();
        if (imsi.length() == 15 && imsi.matches("\\d{15}")) { // Validate 15-digit numeric IMSI
            accField.setText(ACCCalculatorGUI.calculateACC(imsi));
        } else {
            JOptionPane.showMessageDialog(frame, "IMSI must be exactly 15 digits!", "Error", JOptionPane.ERROR_MESSAGE);
        }
    }
}
